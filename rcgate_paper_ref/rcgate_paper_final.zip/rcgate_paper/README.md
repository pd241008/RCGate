# RC-Gate: Springer Nature LaTeX Submission Package

## Paper Title
**RC-Gate: A Reliability-Conditioned Gated Mixture-of-Experts for Black-Box Hallucination Detection, with Controlled and Real-Data Evaluation**

## Authors
- **P. T. Rangesh Pandian** (Department of Computing Technologies, School of Computing, SRM Institute of Science and Technology, Kattankulathur, Tamil Nadu, India)
- **G. Vishal** (Department of Computing Technologies, School of Computing, SRM Institute of Science and Technology, Kattankulathur, Tamil Nadu, India)
- **Divya Mohan** (Corresponding Author: `divyam@srmist.edu.in`; Department of Computing Technologies, School of Computing, SRM Institute of Science and Technology, Kattankulathur, Tamil Nadu, India)

---

## Package Contents
- `main.tex` / `sn-article.tex`: Complete 22-page manuscript formatted under Springer Nature single-column standard (`sn-jnl.cls`). Both filenames contain identical content to satisfy portals expecting either `main.tex` or `sn-article.tex`.
- `main.pdf` / `sn-article.pdf`: Ready-to-read pre-compiled PDF manuscripts.
- `refs.bib`: 32 verified BibTeX citations formatted for Springer Nature citation styles.
- `sn-jnl.cls`: Official Springer Nature journal document class.
- `*.bst`: Complete suite of 10 Springer Nature bibliography style files (`sn-mathphys.bst`, `sn-nature.bst`, `sn-basic.bst`, etc.).
- `figures/`: Vector PDF figures embedded in the manuscript (`auroc_by_type.pdf`, `gate_weights.pdf`).

---

## Compilation Instructions
To build from source using `pdflatex` and `bibtex`:
```bash
pdflatex -interaction=nonstopmode main.tex
bibtex main
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
```
*(Or replace `main` with `sn-article`)*.
